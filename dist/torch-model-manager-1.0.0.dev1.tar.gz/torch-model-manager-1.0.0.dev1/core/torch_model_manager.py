import torchvision.models as models
from torch import nn
import os
import sys
import numpy as np
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
from utils import helpers

class TorchModelManager:
    """
    A class for managing PyTorch models.

    Attributes:
        model: The PyTorch model to manage.
        named_layers: A dictionary containing the named layers of the model.
    """

    def __init__(self, model: nn.Module):
        """
        Initialize PyModelManager with a given PyTorch model.

        Args:
            model (nn.Module): The PyTorch model to manage.
        """
        self.model = model
        self.named_layers = dict()
    
    def get_named_layers(self) -> dict:
        """
        Recursively fetch and store all named layers of the model.

        Returns:
            dict: A dictionary containing the named layers of the model.
        """
        def get_layers_recursive(model_children: dict) -> dict:
            """
            Recursively retrieves all layers in a model.

            Args:
                model_children (dict): A dictionary containing the children layers of a model.

            Returns:
                dict: A dictionary containing all the named layers in the model.
            """
            for name, layer in model_children.items():
                if dict(layer.named_children()) != {}:
                    model_children[name] = get_layers_recursive(dict(layer.named_children()))
                else:
                    model_children[name] = layer
            self.named_layers = model_children
            return self.named_layers
        
        return get_layers_recursive(dict(self.model.named_children()))

    def get_attribute(self, layer: nn.Module, attribute: str) -> any:
        """
        Get a specific attribute of a layer.

        Args:
            layer (nn.Module): The layer.
            attribute (str): The attribute name.

        Returns:
            Any: The value of the attribute.
        """
        assert hasattr(layer, attribute), f'{layer} does not have the attribute {attribute}'
        return getattr(layer, attribute)
    
    def get_layer_by_index(self, index: list) -> nn.Module:
        """
        Get a layer from the model using its index.

        Args:
            index (list): The index path of the layer in the model.

        Returns:
            nn.Module: The layer from the model.
        """
        trace = ['self.model']
        try:
            for ind in index[:-1]:
                
                if isinstance(ind, int):
                    trace.append(f'[{ind}]')
                else:
                    trace.append(f'.{ind}')
            
            if isinstance(index[-1], int):
                layers = eval(''.join(trace))
                return layers[index[-1]]
            else:
                return getattr(eval(''.join(trace)), index[-1])
        except:
            print(f'Layer with index {index} not found')

    def get_layer_by_attribute(self, property: str, value: any, operator: str) -> dict:
        """
        Retrieves layers from the model that have a specific attribute value based on the given property and operator.

        Args:
            property (str): The name of the attribute to check in each layer.
            value (any): The value to compare against the attribute.
            operator (str): The operator to use for comparison. Supported operators are '==', '!=', '>', '<', '>=', and '<='.

        Returns:
            dict: A dictionary mapping the indexes of the layers to the corresponding layer objects.

        Example:
            >>> model_manager = ModelManager()
            >>> layers = model_manager.get_layer_by_attribute('activation', 'relu', '==')
            >>> print(layers)
            {0: <torch.nn.ReLU object at 0x7f9a2e3a8a90>, 2: <torch.nn.ReLU object at 0x7f9a2e3a8b50>}
        """
        def dfs(self, model, property, value, operator, layers, indexes, tmp=None, depth=0):
            if tmp is None:
                tmp = []

            for name, layer in model.named_children():
                tmp.append(name)
                if hasattr(layer, property) and helpers.bi_operator(operator, self.get_attribute(layer, property), value):
                    layers.append(layer)
                    indexes.append(tmp.copy())

                # Recursive call
                dfs(self, layer, property, value, operator, layers, indexes, tmp, depth+1)

                # Pop the last element to backtrack
                tmp.pop()

        layers = []
        indexes = []

        dfs(self, self.model, property, value, operator, layers, indexes)

        return helpers.create_dictionary(helpers.convert_to_int(indexes), layers)
    

    def get_layer_by_attributes(self, conditions: dict) -> dict:
        """
        Retrieves layers that satisfy the given conditions.

        Args:
            conditions (dict): A dictionary containing the conditions for layer retrieval.
                The dictionary should have the following structure:
                {
                    'and': [
                        {'property': ['attribute_name', 'attribute_value'], 'operator': 'comparison_operator'},
                        ...
                    ],
                    'or': [
                        {'property': ['attribute_name', 'attribute_value'], 'operator': 'comparison_operator'},
                        ...
                    ]
                }

                - 'and' key represents the conditions that must be satisfied simultaneously.
                - 'or' key represents the conditions where at least one of them must be satisfied.

                Each condition is a dictionary with the following keys:
                - 'property': A list containing the attribute name and attribute value to be compared.
                - 'operator': The comparison operator to be used for the attribute comparison.

        Returns:
            dict: A dictionary containing the layers that satisfy the given conditions.

        Example:
            >>> conditions = {
            >>>     'and': [
            >>>         {'property': ['name', 'layer1'], 'operator': '=='},
            >>>         {'property': ['type', 'convolutional'], 'operator': '=='}
            >>>     ],
            >>>     'or': [
            >>>         {'property': ['name', 'layer2'], 'operator': '=='},
            >>>         {'property': ['type', 'pooling'], 'operator': '=='}
            >>>     ]
            >>> }
            >>> result = get_layer_by_attributes(conditions)
            >>> print(result)
            {'layer1': {'name': 'layer1', 'type': 'convolutional'}, 'layer2': {'name': 'layer2', 'type': 'pooling'}}
        """
        result = dict()
        first_iter = True
        for operator, operands in conditions.items():
            tmp_statement_result = dict()
            if operator == 'and':
                for stat in operands:
                    prop = list(stat.values())[0][0]
                    value = list(stat.values())[0][1]
                    op = list(stat.keys())[0]
                    search_result = self.get_layer_by_attribute(prop, value, op)
                    if first_iter:
                        tmp_statement_result = search_result
                        first_iter = False
                    else:
                        tmp_statement_result = helpers.intersect_dicts(tmp_statement_result, search_result)
            elif operator == 'or':
                for stat in operands:
                    prop = list(stat.values())[0][0]
                    value = list(stat.values())[0][1]
                    op = list(stat.keys())[0]
                    search_result = self.get_layer_by_attribute(prop, value, op)
                    if first_iter:
                        tmp_statement_result = search_result
                        first_iter = False
                    else:
                        tmp_statement_result = helpers.union_dicts(tmp_statement_result, search_result)
            result = helpers.union_dicts(result, tmp_statement_result)
        return result
                    
    def get_layer_by_instance(self, instance_type: type) -> dict:
        """
        Search for layers in the model by their instance type.

        Args:
            instance_type (type): The instance type of the layers to search for.

        Returns:
            dict: A dictionary mapping the indexes of found layers to the layers themselves.
        """
        def dfs(self, model, instance_type, layers, indexes, tmp=None, depth=0):
            if tmp is None:
                tmp = []

            for name, layer in model.named_children():
                tmp.append(name)
                if isinstance(layer, instance_type):
                    layers.append(layer)
                    indexes.append(tmp.copy())

                # Recursive call
                dfs(self, layer, instance_type, layers, indexes, tmp, depth + 1)

                # Pop the last element to backtrack
                tmp.pop()

        layers = []
        indexes = []

        dfs(self, self.model, instance_type, layers, indexes)

        return helpers.create_dictionary(helpers.convert_to_int(indexes), layers)    

    def delete_layer_by_index(self, index: list) -> None:
        """
        Delete a layer from the model using its index.

        Args:
            index (list): The index path of the layer in the model.
        """
        trace = ['self.model']
        for ind in index[:-1]:
            
            if isinstance(ind, int):
                trace.append(f'[{ind}]')
            else:
                trace.append(f'.{ind}')
        
        if isinstance(index[-1], int):
            layers = eval(''.join(trace))
            del layers[index[-1]]
        else:
            delattr(eval(''.join(trace)), index[-1])

    def delete_layer_by_attribute(self, property: str, value: any, operator: str) -> None:
        """
        Deletes a layer from the model based on the specified attribute.

        Args:
            property (str): The attribute to search for.
            value: The value to compare against.
            operator (str): The operator to use for comparison.

        Returns:
            None

        Raises:
            None
        """
        search_res = self.get_layer_by_attribute(property, value, operator)

        while list(search_res.keys()) != []:
            self.delete_layer_by_index(list(search_res.keys())[0])
            search_res = self.get_layer_by_attribute(property, value, operator)

    def delete_layer_by_attributes(self, conditions: dict) -> None:
        """
        Deletes layers that match the given attributes.

        Parameters:
        - conditions (dict): A dictionary of attribute-value pairs to match the layers.

        Returns:
        None
        """
        search_res = self.get_layer_by_attributes(conditions)

        while list(search_res.keys()) != []:
            self.delete_layer_by_index(list(search_res.keys())[0])
            search_res = self.get_layer_by_attributes(conditions)


    def delete_layer_by_instance(self, instance_type: type) -> None:
        """
        Delete layers from the model by their instance type.

        Args:
            instance_type (type): The instance type of the layers to delete.
        """
        search_res = self.get_layer_by_instance(instance_type)
 
        while list(search_res.keys()) != []:
            self.delete_layer_by_index(list(search_res.keys())[0])
            search_res = self.get_layer_by_instance(instance_type)